import java.util.*;

public class Main {

    public static void main(String[] args) {

        StudentManager manager = new StudentManager("students.txt");
        Scanner sc = new Scanner(System.in);

        while(true) {
            System.out.println("===== Capstone Student Menu =====");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Search by Name");
            System.out.println("4. Delete by Name");
            System.out.println("5. Sort by Marks");
            System.out.println("6. Random Access Read");
            System.out.println("7. Save and Exit");
            System.out.print("Enter choice: ");

            int ch = sc.nextInt();
            sc.nextLine();

            switch(ch) {
                case 1: manager.addStudent(); break;
                case 2: manager.displayAll(); break;
                case 3:
                    System.out.print("Enter Name: ");
                    manager.searchByName(sc.nextLine());
                    break;

                case 4:
                    System.out.print("Enter Name: ");
                    manager.deleteByName(sc.nextLine());
                    break;

                case 5: manager.sortByMarks(); break;

                case 6: manager.showRandomAccess(); break;

                case 7: manager.saveAndExit(); break;

                default: System.out.println("Invalid choice!");
            }
        }
    }
}
