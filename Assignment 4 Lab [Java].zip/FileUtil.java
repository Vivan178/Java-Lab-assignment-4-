public import java.io.*;
import java.util.*;

public class FileUtil {

    public static ArrayList<Student> readFromFile(String filename) {
        ArrayList<Student> list = new ArrayList<>();
        File file = new File(filename);

        try {
            if (!file.exists()) {
                file.createNewFile();
            }

            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    String[] parts = line.split(",");
                    int roll = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    String email = parts[2];
                    String course = parts[3];
                    double marks = Double.parseDouble(parts[4]);
                    list.add(new Student(roll, name, email, course, marks));
                }
            }
            br.close();

        } catch (Exception e) {
            System.out.println("Error reading file: " + e.getMessage());
        }

        return list;
    }

    public static void writeToFile(String filename, ArrayList<Student> list) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));

            for (Student s : list) {
                bw.write(s.toString());
                bw.newLine();
            }
            bw.close();

        } catch (Exception e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}
 {
    
}
