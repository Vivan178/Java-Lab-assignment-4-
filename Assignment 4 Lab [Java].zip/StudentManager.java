import java.util.*;
import java.io.*;

public class StudentManager {

    private ArrayList<Student> students;
    private String filename;

    public StudentManager(String filename) {
        this.filename = filename;
        students = FileUtil.readFromFile(filename);
        System.out.println("Loaded students from file:");
        displayAll();
    }

    public void addStudent() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Roll No: ");
        int roll = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Email: ");
        String email = sc.nextLine();
        System.out.print("Enter Course: ");
        String course = sc.nextLine();
        System.out.print("Enter Marks: ");
        double marks = sc.nextDouble();

        students.add(new Student(roll, name, email, course, marks));
    }

    public void displayAll() {
        Iterator<Student> it = students.iterator();
        while(it.hasNext()) {
            it.next().print();
        }
    }

    public void searchByName(String name) {
        boolean found = false;
        for (Student s : students) {
            if (s.getName().equalsIgnoreCase(name)) {
                s.print();
                found = true;
            }
        }
        if (!found) System.out.println("Student not found!");
    }

    public void deleteByName(String name) {
        Iterator<Student> it = students.iterator();
        boolean found = false;

        while(it.hasNext()) {
            Student s = it.next();
            if (s.getName().equalsIgnoreCase(name)) {
                it.remove();
                found = true;
                System.out.println("Deleted successfully.");
            }
        }
        if (!found) System.out.println("Student not found!");
    }

    public void sortByMarks() {
        students.sort(Comparator.comparingDouble(Student::getMarks));
        System.out.println("Sorted Student List by Marks:");
        displayAll();
    }

    public void saveAndExit() {
        FileUtil.writeToFile(filename, students);
        System.out.println("Records saved successfully.");
        System.exit(0);
    }

    // RandomAccess Example
    public void showRandomAccess() {
        try {
            RandomAccessFile raf = new RandomAccessFile(filename, "r");
            System.out.println("Reading first 50 bytes randomly:");
            for (int i = 0; i < 50 && raf.getFilePointer() < raf.length(); i++) {
                System.out.print((char) raf.read());
            }
            System.out.println();
            raf.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
